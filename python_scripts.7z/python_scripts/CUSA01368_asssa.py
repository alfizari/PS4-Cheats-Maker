value = read_offset(offset, save_data, length=4)
