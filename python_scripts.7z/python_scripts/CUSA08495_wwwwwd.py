# Author: wd
# CUSA: CUSA08495

# Your script code here
# Available variables:
#   save_data - the current save file data (bytearray)
#   current_cusa - the current CUSA ID

# Example usage:
# value = read_int(0x1000, save_data)
# write_int(0x1000, 999999, save_data)
