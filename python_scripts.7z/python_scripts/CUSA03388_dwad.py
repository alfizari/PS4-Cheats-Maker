# Script: dwad
# Author: Unknown

adww